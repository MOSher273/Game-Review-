<?php $__env->startSection('main-section'); ?>
    <div class="mt-4 p-5 bg-success text-white text-center rounded">
        <h1>Dashboard</h1>
    </div>
    <hr>
    <div class="mt-5">
        <div class="row">
            <div class="col-2"></div>
            <div class="col-8">
                <h3 class="text-center">Write A Game Review</h3>
                <form class="mt-2" action="<?php echo e(route('poem.add')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Game Name</label>
                        <input type="text" class="form-control" name="title">
                    </div>
                    <div class="form-floating">
                        <!-- <label for="floatingTextarea2">Your Review</label> -->
                        <textarea class="form-control" name="body" style="height: 400px"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary mt-3">Submit</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rafi_admin/Desktop/gameReview/resources/views/dashboard.blade.php ENDPATH**/ ?>