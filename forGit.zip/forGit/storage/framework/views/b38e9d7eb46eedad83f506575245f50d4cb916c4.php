<?php $__env->startSection('main-section'); ?>
    <div class="mt-4 p-5 bg-success text-white text-center rounded">
        <h1>This is Homepage</h1>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Rihan\poem-blog\resources\views/welcome.blade.php ENDPATH**/ ?>