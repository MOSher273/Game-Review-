<?php if(Auth::check()): ?>
    <?php if($isRated): ?>
        <div class="row mb-3" id="rated">
            <div class="col-3"></div>
            <div class="col-6 text-center" style="background-color: #d4dae5; padding: 10px">
                <p><b>Thank you for your Feedback!</b></p>
                <p style="margin: 0;">Your Rating: <?php echo e($rating); ?></p>
                <p style="margin: 0;">Overall Rating: <?php echo e($overall_rating); ?></p>
            </div>
        </div>
    <?php else: ?>
        <div class="row mb-3" id="rateme">
            <div class="col-3"></div>
            <div class="col-6 text-center" style="background-color: #d4dae5; padding: 10px">
                <p><b>Please Share Your Feedback:</b></p>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="rating" value="1">
                        <label class="form-check-label" for="inlineRadio1">1</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="rating" value="2">
                        <label class="form-check-label" for="inlineRadio1">2</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="rating" value="3">
                        <label class="form-check-label" for="inlineRadio1">3</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="rating" value="4">
                        <label class="form-check-label" for="inlineRadio1">4</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="rating" value="5">
                        <label class="form-check-label" for="inlineRadio1">5</label>
                    </div>
                    <br>
                    <button onclick="submitThisRating(<?php echo e($poem->id); ?>, <?php echo e(Auth::id()); ?>)" class="btn btn-secondary btn-sm mt-3">Rate</button>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <div class="text-center">
            <h2><?php echo e($poem->title); ?></h2>
            <h6>By <?php echo e($poem->author->name); ?></h6>
        </div>
        <hr>
    </div>
</div>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <p style="text-align: justify;"><?php echo e($poem->body); ?></p>
    </div>
</div>
<hr>

    <div class="row mb-3">
        <div class="col-3"></div>
        <div class="col-6" style="background-color: #d4dae5; padding: 10px">
            <p><b>Comments:</b></p>
            <?php if(Auth::check()): ?>
            <div class="form-floating">
                <textarea id="commentss" class="form-control" name="body" style="height: 60px"></textarea>
                <label for="floatingTextarea2">Your Comment</label>
            </div>
            <button onclick="submitThisComment(<?php echo e($poem->id); ?>, <?php echo e(Auth::id()); ?>)" class="btn btn-success btn-sm mt-3">Submit</button>
            <?php endif; ?>
            <div id="commentsection" style="margin-top: 10px">
                <?php if(count($comments)): ?>
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex" id="<?php echo e("comment".$comment->id); ?>" style="border: 1px solid; padding: 7px; margin: 5px;background-color: white">
                            <div class="flex-shrink-0">
                                <img src="<?php echo e(asset('images/profile-logo.png')); ?>" width="60px">
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h5 style="margin: 0px"><?php echo e($comment->author->name); ?></h5>
                                <p style="margin: 0px"><?php echo e($comment->comment); ?></p>
                            </div>

                            <?php if(Auth::id() == $poem->user_id): ?>
                                <button onclick="hideThisComment(<?php echo e($comment->id); ?>)" class="btn btn-danger btn-sm" id="viewbutton">Hide</button>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php /**PATH E:\Freelance\sher\game_review\resources\views/homepages/poemview.blade.php ENDPATH**/ ?>