<div class="row mb-3" id="rated">
    <div class="col-3"></div>
    <div class="col-6 text-center" style="background-color: #d4dae5; padding: 10px">
        <p><b>Thank you for your Feedback!</b></p>
        <p style="margin: 0;">Your Rating: <?php echo e($rating); ?></p>
        <p style="margin: 0;">Overall Rating: <?php echo e($overall_rating); ?></p>
    </div>
</div>
<?php /**PATH F:\Rihan\poem-blog\resources\views/homepages/ratingview.blade.php ENDPATH**/ ?>