<?php $__env->startSection('main-section'); ?>
    <div class="mt-4 p-5 bg-success text-white text-center rounded">
        <h1>Dashboard</h1>
    </div>
    <hr>
    <div class="mt-5">
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">
                <h3 class="text-center">Create A Poem</h3>
                <form class="mt-2" action="<?php echo e(route('poem.add')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Title</label>
                        <input type="text" class="form-control" name="title">
                    </div>
                    <div class="form-floating">
                        <textarea class="form-control" name="body" style="height: 100px"></textarea>
                        <label for="floatingTextarea2">Your Poem</label>
                    </div>
                    <button type="submit" class="btn btn-primary mt-3">Submit</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Rihan\poem-blog\resources\views/dashboard.blade.php ENDPATH**/ ?>