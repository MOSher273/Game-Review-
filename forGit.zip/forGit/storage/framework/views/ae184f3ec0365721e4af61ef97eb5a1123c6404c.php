<?php $__env->startSection('main-section'); ?>
    <div class="mt-4 p-5 text-white text-center rounded" style="background-color: #68d6e8;">
        <h1>Welcome to Gamer's Den</h1>
        <a id="backbutton" class="btn btn-warning mt-3" style="display: none" href="<?php echo e(route('welcome')); ?>">Go Back to List</a>
    </div>
    <hr>
    <div class="container" id="main">
        <div class="row">
                <?php if(count($poems)): ?>
                    <?php $__currentLoopData = $poems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-3">
                            <div class="card" style="width: 18rem;">
                                <img src="<?php echo e(asset('images/poem-logo.png')); ?>" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($poem->title); ?></h5>
                                    <p style="margin: 0px">by <?php echo e($poem->author->name); ?></p>
                                    <?php if($overall_ratings[$loop->iteration-1] == 0): ?>
                                        <span class="rating" data-default-rating="<?php echo e($overall_ratings[$loop->iteration-1]); ?>" disabled></span> (Not Rated Yet)<br><br>
                                    <?php else: ?>
                                        <span class="rating" data-default-rating="<?php echo e($overall_ratings[$loop->iteration-1]); ?>" disabled></span><br>
                                    <?php endif; ?>
                                    <button onclick="getPoem(<?php echo e($poem->id); ?>, <?php echo e(Auth::id()); ?>)" class="btn btn-info btn-block" id="viewbutton">View</button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
    <script>
        function getPoem(id, userid){
            $.ajax({
                url: "get-poem",
                data: {'poem_id': id, 'user_id': userid},
                success: function(result){
                    $('#backbutton').css("display", "inline");
                    $('#main').empty();
                    $('#main').append(result);
                }
            });
        }

        function submitThisRating(poem_id, auth_id){
            var rating = parseInt($(".form-check-input:checked").val());
            $.ajax({
                url: "submit-rating",
                data: {'poem_id': poem_id, 'user_id': auth_id, 'rating': rating},
                success: function(result){
                    $('#rateme').fadeOut();
                    $('#main').prepend(result);
                }
            });
        }

        function submitThisComment(poem_id, auth_id){
            var comment = $("#commentss").val();
            $.ajax({
                url: "submit-comment",
                data: {'poem_id': poem_id, 'user_id': auth_id, 'comment': comment},
                success: function(result){
                    $("#commentss").val('');
                    $('#commentsection').empty();
                    $('#commentsection').prepend(result);
                }
            });
        }

        function hideThisComment(comment_id){
            var theid = "#comment".concat(comment_id);
            $.ajax({
                url: "hide-comment",
                data: {'comment_id': comment_id},
                success: function(result){
                    $(theid).remove();
                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rafi_admin/Desktop/gameReview/resources/views/front.blade.php ENDPATH**/ ?>