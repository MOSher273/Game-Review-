<!DOCTYPE html>
<html lang="en">
<head>
    <title>Dashboard</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="stylesheet" href="<?php echo e(asset('SimpleStarRating.css')); ?>">
    <script src="<?php echo e(asset('SimpleStarRating.js')); ?>"></script>
</head>
<body>

<nav class="navbar navbar-expand-sm" style="background-color: #008094;">
    <div class="container-fluid">
        <a class="navbar-brand" href="<?php echo e(route('welcome')); ?>">
            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Avatar Logo" style="width:100px;" class="rounded-pill">
        </a>
        <a class="navbar-brand" style="text-decoration: none; color: black; font-weight: bold; font-size: 30px" href="<?php echo e(route('welcome')); ?>">Gamer's Den</a>
        <div class="collapse navbar-collapse" id="mynavbar">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                </li>
                <li class="nav-item">
                </li>
                <li class="nav-item">
                </li>
            </ul>
            <div class="d-flex">
                <?php if(Route::has('login')): ?>
                    <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                        <?php if(auth()->guard()->check()): ?>
                            <div class="dropdown">
                                <button type="button" class="btn btn-warning dropdown-toggle" data-bs-toggle="dropdown">
                                    Welcome <?php echo e(Auth::user()->name); ?>

                                </button>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
                                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                this.closest('form').submit();">Logout</a></li>
                                    </form>
                                </ul>
                            </div>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="btn btn-success">Log in</a>
                            <?php if(Route::has('register')): ?>
                                <a href="<?php echo e(route('register')); ?>" class="btn btn-success">Register</a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<div class="container">
    <?php echo $__env->yieldContent('main-section'); ?>
</div>

<?php echo $__env->yieldPushContent('scripts'); ?>

<script>
    var ratings = document.getElementsByClassName('rating');

    for (var i = 0; i < ratings.length; i++) {
        var r = new SimpleStarRating(ratings[i]);

        ratings[i].addEventListener('rate', function(e) {
            console.log('Rating: ' + e.detail);
        });
    }
</script>

</body>
</html>
<?php /**PATH /Users/rafi_admin/Desktop/gameReview/resources/views/layouts/welcome.blade.php ENDPATH**/ ?>