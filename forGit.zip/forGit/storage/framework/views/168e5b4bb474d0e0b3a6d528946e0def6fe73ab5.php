<?php $__env->startSection('main-section'); ?>
    <div class="mt-4 p-5 text-white text-center rounded" style="background-color: #008094;">
        <h1>Welcome to Poetry Craft</h1>
        <a id="backbutton" class="btn btn-warning mt-3" style="display: none" href="<?php echo e(route('welcome')); ?>">Go Back to List</a>
    </div>
    <hr>
    <div class="container" id="main">
        <div class="row">
            <div class="col-2"></div>
            <div class="col-8">
                <?php if(count($poems)): ?>
                    <?php $__currentLoopData = $poems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex" style="border: 1px solid; padding: 7px; margin: 5px">
                            <div class="flex-shrink-0">
                                <img src="<?php echo e(asset('images/poem-logo.png')); ?>" width="100px">
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h3 style="margin: 0px"><?php echo e($poem->title); ?></h3>
                                <p style="margin: 0px">Author: <?php echo e($poem->author->name); ?></p>
                                <p>Rating: <?php echo e($overall_ratings[$loop->iteration-1]); ?>/5</p>
                            </div>
                            <button onclick="getPoem(<?php echo e($poem->id); ?>, <?php echo e(Auth::id()); ?>)" class="btn btn-warning" id="viewbutton">View</button>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
    <script>
        function getPoem(id, userid){
            $.ajax({
                url: "get-poem",
                data: {'poem_id': id, 'user_id': userid},
                success: function(result){
                    $('#backbutton').css("display", "inline");
                    $('#main').empty();
                    $('#main').append(result);
                }
            });
        }

        function submitThisRating(poem_id, auth_id){
            var rating = parseInt($(".form-check-input:checked").val());
            $.ajax({
                url: "submit-rating",
                data: {'poem_id': poem_id, 'user_id': auth_id, 'rating': rating},
                success: function(result){
                    $('#rateme').fadeOut();
                    $('#main').prepend(result);
                }
            });
        }

        function submitThisComment(poem_id, auth_id){
            var comment = $("#commentss").val();
            $.ajax({
                url: "submit-comment",
                data: {'poem_id': poem_id, 'user_id': auth_id, 'comment': comment},
                success: function(result){
                    $("#commentss").val('');
                    $('#commentsection').empty();
                    $('#commentsection').prepend(result);
                }
            });
        }

        function hideThisComment(comment_id){
            var theid = "#comment".concat(comment_id);
            $.ajax({
                url: "hide-comment",
                data: {'comment_id': comment_id},
                success: function(result){
                    $(theid).remove();
                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Rihan\poem-blog\resources\views/front.blade.php ENDPATH**/ ?>