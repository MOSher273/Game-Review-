<?php

namespace App\Http\Controllers;

use App\Models\Game;
use App\Models\GameComments;
use App\Models\GameRatings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class GameController extends Controller
{
    public function home(){
        $games = Game::all();
        $overall_ratings = [];
        foreach($games as $game){
            array_push($overall_ratings, round(GameRatings::where('game_id', $game->id)->avg('rating'), 2));
        }
        return view('front', compact('games', 'overall_ratings'));
    }

    public function addGame(Request $request){
        Game::create([
            'user_id' => Auth::id(),
            'title' => $request->title,
            'body' => $request->body
        ]);
        return redirect()->route('dashboard');
    }

    public function getGame(Request $request){
        $game = Game::where('id', $request->game_id)->first();
        $isRated = false;

        //For Rating
        $rating = 0;
        if($request->has('user_id')){
            $rating = GameRatings::where([['user_id', $request->user_id],['game_id', $request->game_id]])->first();
        }
        if($rating!= null){
            $isRated = true;
            $rating = $rating->rating;
        }
        $overall_rating = round(GameRatings::where('game_id', $request->game_id)->avg('rating'), 2);

        //For Comments
        $comments = GameComments::where([['game_id', $request->game_id], ['status', 1]])->get();
        return view('homepages.gameview', compact('game', 'isRated', 'rating', 'overall_rating', 'comments'));
    }

    public function submitRating(Request $request){
        GameRatings::create([
            'user_id' => $request->user_id,
            'game_id' => $request->game_id,
            'rating' => $request->rating,
        ]);
        $rating = $request->rating;
        $overall_rating = round(GameRatings::where('game_id', $request->game_id)->avg('rating'), 2);
        return view('homepages.ratingview', compact('rating', 'overall_rating'));
    }

    public function submitComment(Request $request){
        GameComments::create([
            'user_id' => $request->user_id,
            'game_id' => $request->game_id,
            'comment' => $request->comment,
            'status' => 1,
        ]);
        $comments = GameComments::where([['game_id', $request->game_id], ['status', 1]])->get();
        return view('homepages.commentview', compact('comments'));
    }

    public function hideComment(Request $request){
        GameComments::where('id', $request->comment_id)->update([
            'status'=>2,
        ]);
        return false;
    }
}
