<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GameRatings extends Model
{
    use HasFactory;

    protected $table = "game_ratings";
    public $timestamps = false;
    protected $fillable = [
        'user_id',
        'game_id',
        'rating'
    ];
}
