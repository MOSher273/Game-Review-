@extends('layouts.welcome')

@section('main-section')
    <div class="p-5 text-white text-center rounded" style="background-color: #9BE8D8;">
        <h1 style="color: black">Welcome to Gamer's Den</h1>
        <a id="backbutton" class="btn btn-warning mt-3" style="display: none" href="{{route('welcome')}}">Go Back to List</a>
    </div>
    <hr>
    <div class="container" id="main">
        <div class="row">
                @if(count($games))
                    @foreach($games as $game)
                        <div class="col-3">
                            <div class="card" style="width: 18rem;">
                                <img src="{{asset('images/game-logo.png')}}" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title">{{$game->title}}</h5>
                                    <p style="margin: 0px">by {{$game->author->name}}</p>
                                    @if($overall_ratings[$loop->iteration-1] == 0)
                                        <span class="rating" data-default-rating="{{$overall_ratings[$loop->iteration-1]}}" disabled></span> (Not Rated Yet)<br><br>
                                    @else
                                        <span class="rating" data-default-rating="{{$overall_ratings[$loop->iteration-1]}}" disabled></span><br>
                                    @endif
                                    <button onclick="getGame({{$game->id}}, {{Auth::id()}})" class="btn btn-info" id="viewbutton">View</button>
                                </div>
                            </div>
                        </div>
                    @endforeach
                @endif
        </div>
    </div>
@endsection


@push('scripts')
    <script>
        function getGame(id, userid){
            $.ajax({
                url: "get-game",
                data: {'game_id': id, 'user_id': userid},
                success: function(result){
                    $('#backbutton').css("display", "inline");
                    $('#main').empty();
                    $('#main').append(result);
                }
            });
        }

        function submitThisRating(game_id, auth_id){
            var rating = parseInt($(".form-check-input:checked").val());
            $.ajax({
                url: "submit-rating",
                data: {'game_id': game_id, 'user_id': auth_id, 'rating': rating},
                success: function(result){
                    $('#rateme').fadeOut();
                    $('#main').prepend(result);
                }
            });
        }

        function submitThisComment(game_id, auth_id){
            var comment = $("#commentss").val();
            $.ajax({
                url: "submit-comment",
                data: {'game_id': game_id, 'user_id': auth_id, 'comment': comment},
                success: function(result){
                    $("#commentss").val('');
                    $('#commentsection').empty();
                    $('#commentsection').prepend(result);
                }
            });
        }

        function hideThisComment(comment_id){
            var theid = "#comment".concat(comment_id);
            $.ajax({
                url: "hide-comment",
                data: {'comment_id': comment_id},
                success: function(result){
                    $(theid).remove();
                }
            });
        }
    </script>
@endpush
