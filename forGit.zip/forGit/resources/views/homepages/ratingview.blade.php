<div class="row mb-3" id="rated">
    <div class="col-3"></div>
    <div class="col-6 text-center" style="background-color: #d4dae5; padding: 10px">
        <p><b>Thank you for your Feedback!</b></p>
        <p style="margin: 0;">Your Rating: {{$rating}}</p>
        <p style="margin: 0;">Overall Rating: {{$overall_rating}}</p>
    </div>
</div>
