@extends('layouts.welcome')

@section('main-section')
    <div class="p-5 text-white text-center rounded" style="background-color: #9BE8D8">
        <h1 style="color: black">Dashboard</h1>
    </div>
    <hr>
    <div class="mt-5 mb-4">
        <div class="row">
            <div class="col-2"></div>
            <div class="col-8">
                <h3 class="text-center">Write A Game Review</h3>
                <form class="mt-2" action="{{route('game.add')}}" method="POST">
                    @csrf
                    <div class="mb-3">
                        <label class="form-label">Game Name</label>
                        <input type="text" class="form-control" name="title">
                    </div>
                    <div class="form-floating">
                        <!-- <label for="floatingTextarea2">Your Review</label> -->
                        <textarea class="form-control" name="body" style="height: 400px"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary mt-3">Submit</button>
                </form>
            </div>
        </div>
    </div>
@endsection
